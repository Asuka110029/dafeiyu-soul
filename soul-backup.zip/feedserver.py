#!/usr/bin/env python3
"""独立投喂服务：多选/拖拽上传，原样落盘到 /root/inbox"""
import os, re, html
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

INBOX = '/root/inbox'
PORT = 3099

PAGE = """<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>投喂大肥鱼</title>
<style>
 body{font:16px/1.6 system-ui;margin:0;padding:20px;background:#f7fbff;color:#234}
 h1{font-size:20px;margin:0 0 4px} p{color:#5b7f96;margin:0 0 16px;font-size:14px}
 .box{background:#fff;border:2px dashed #bcdcee;border-radius:14px;padding:22px;text-align:center}
 .box.over{background:#eaf6ff;border-color:#4a9fd8}
 input[type=file]{font-size:15px;width:100%}
 button{margin-top:14px;padding:10px 24px;border:0;border-radius:10px;background:#2b6f9e;color:#fff;font-size:15px}
 ul{padding-left:18px;font-size:14px;color:#456} li{margin:2px 0}
 #log{margin-top:14px;font-size:14px;color:#2b6f9e}
</style>
<h1>投喂大肥鱼 🐟</h1>
<p>可以一次选多张（长按多选），或者直接拖进来。原样落盘，不压缩。</p>
<form class="box" id="box" method="post" action="/upload" enctype="multipart/form-data">
  <input type="file" name="files" id="f" multiple>
  <br><button type="submit">丢进去</button>
</form>
<div id="log"></div>
<h3>已经在 <code>/root/inbox</code> 里的</h3><ul id="l"><li>（空）</li></ul>
<script>
const box=document.getElementById('box'), f=document.getElementById('f'), log=document.getElementById('log');
['dragover','dragenter'].forEach(e=>box.addEventListener(e,ev=>{ev.preventDefault();box.classList.add('over')}));
['dragleave','drop'].forEach(e=>box.addEventListener(e,ev=>{ev.preventDefault();box.classList.remove('over')}));
box.addEventListener('drop',ev=>{ f.files=ev.dataTransfer.files; log.textContent='已选中 '+f.files.length+' 个文件'; });
f.addEventListener('change',()=>{ log.textContent='已选中 '+f.files.length+' 个文件'; });
document.getElementById('box').addEventListener('submit',async ev=>{
  ev.preventDefault();
  const fs=[...f.files]; if(!fs.length) return;
  let ok=0;
  for(const file of fs){
    const fd=new FormData(); fd.append('files', file, file.name);
    try{ const r=await fetch('/upload',{method:'POST',body:fd}); if(r.ok) ok++; }catch(e){}
    log.textContent=`上传中 ${ok}/${fs.length} …`;
  }
  log.textContent=`完成 ${ok}/${fs.length}，可以继续丢`;
  f.value=''; refresh();
});
async function refresh(){
  try{ const r=await fetch('/list'); const d=await r.json();
    const ul=document.getElementById('l');
    ul.innerHTML = d.files.length ? d.files.map(x=>'<li>'+x.name+' — '+Math.round(x.size/1024)+' KB</li>').join('') : '<li>（空）</li>';
  }catch(e){}
}
refresh();
</script>"""

def parse_multipart(body: bytes, boundary: bytes):
    parts = []
    sep = b'--' + boundary
    for chunk in body.split(sep):
        if not chunk.strip() or chunk.strip() == b'--':
            continue
        chunk = chunk.lstrip(b'\r\n')
        head, _, data = chunk.partition(b'\r\n\r\n')
        if not _:
            continue
        m = re.search(rb'filename="([^"]*)"', head)
        if not m:
            continue
        name = m.group(1).decode('utf-8', 'replace')
        data = data.rstrip(b'\r\n')
        parts.append((name, data))
    return parts

class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass
    def _send(self, code, ctype, payload: bytes):
        self.send_response(code)
        self.send_header('content-type', ctype)
        self.send_header('cache-control', 'no-store')
        self.send_header('content-length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)
    def do_GET(self):
        if self.path.startswith('/list'):
            os.makedirs(INBOX, exist_ok=True)
            files = [{'name': n, 'size': os.path.getsize(os.path.join(INBOX, n))}
                     for n in sorted(os.listdir(INBOX)) if not n.startswith('.')]
            import json
            self._send(200, 'application/json; charset=utf-8', json.dumps({'files': files}).encode())
        else:
            self._send(200, 'text/html; charset=utf-8', PAGE.encode())
    def do_POST(self):
        ctype = self.headers.get('content-type', '')
        m = re.search(r'boundary=(.+)', ctype)
        n = int(self.headers.get('content-length', 0))
        body = self.rfile.read(n)
        if not m:
            self._send(400, 'text/plain', b'no boundary'); return
        boundary = m.group(1).strip('"').encode()
        saved = []
        for name, data in parse_multipart(body, boundary):
            safe = re.sub(r'[^\w.\-\u4e00-\u9fa5]', '_', os.path.basename(name)) or 'file'
            os.makedirs(INBOX, exist_ok=True)
            with open(os.path.join(INBOX, safe), 'wb') as fh:
                fh.write(data)
            saved.append(f'{safe} ({len(data)//1024} KB)')
        self._send(200, 'application/json; charset=utf-8',
                   ('{"ok":true,"saved":' + str(len(saved)) + '}').encode())

if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
