#!/usr/bin/env python3
"""同义词扩展：把查询词按组展开"""
import json
PATH = '/root/stickers/synonyms.json'
_cache = None

def load():
    global _cache
    if _cache is None:
        _cache = json.load(open(PATH, encoding='utf-8'))['groups']
    return _cache

def expand(tokens):
    """给定 token 集合，返回扩展后的集合（含同组词及其二元组）"""
    groups = load()
    out = set(tokens)
    for g in groups:
        if any(t in g or any(t in w or w in t for w in g if len(w) > 1) for t in tokens):
            out |= set(g)
    # 同组词也切成二元组，提高匹配概率
    extra = set()
    for w in out:
        for i in range(len(w) - 1):
            extra.add(w[i:i+2])
    return out | extra
