#!/usr/bin/env python3
"""合并两台设备的记忆：merge_memory.py <主库.json> <另一台.json> [-w]
规则：同一个 key，取 at 更新的那条；新的 key 直接并入；输出冲突清单。
"""
import json, sys, shutil, datetime

def load(p):
    return {r['key']: r for r in json.load(open(p, encoding='utf-8')) if r.get('key')}

def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    main_p, other_p = sys.argv[1], sys.argv[2]
    write = '-w' in sys.argv
    A, B = load(main_p), load(other_p)
    merged = dict(A)
    conflicts, added = [], []
    for k, rb in B.items():
        if k not in A:
            merged[k] = rb; added.append(k); continue
        ra = A[k]
        if ra.get('text') == rb.get('text'):
            continue
        ta, tb = ra.get('at',''), rb.get('at','')
        win = rb if tb > ta else ra
        merged[k] = win
        conflicts.append((k, 'B' if win is rb else 'A', ta[:19], tb[:19]))
    print(f'主库 {len(A)} 条 | 对方 {len(B)} 条 | 合并后 {len(merged)} 条')
    print(f'新增 {len(added)} 条: {added[:8]}')
    print(f'冲突 {len(conflicts)} 条（已按时间取新）:')
    for c in conflicts[:10]: print('   ', c)
    if write:
        shutil.copy(main_p, main_p + '.bak')
        out = [merged[k] for k in merged]
        json.dump(out, open(main_p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f'已写入 {main_p}（原文件备份为 .bak）')
    else:
        print('（只预演，没写入。加 -w 才真的合并）')

if __name__ == '__main__': main()
