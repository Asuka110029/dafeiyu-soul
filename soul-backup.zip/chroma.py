#!/usr/bin/env python3
"""HSV 色相抠像：只认绿色方向，蓝/白/红不误抠。用法: chroma.py in.gif out.webp [帧数]"""
import sys
from PIL import Image

GREEN_HUE_MIN = 50    # PIL 色相 0-255 制，约 70°
GREEN_HUE_MAX = 121   # 约 170°
SAT_MIN = 0.25
VAL_MIN = 0.15
FEATHER = 6

def key_frame(img: Image.Image) -> Image.Image:
    rgba = img.convert('RGBA')
    hsv = rgba.convert('HSV')
    px_rgba = rgba.load()
    px_hsv = hsv.load()
    w, h = rgba.size
    for y in range(h):
        for x in range(w):
            hh, ss, vv = px_hsv[x, y]
            r, g, b, a = px_rgba[x, y]
            rb = max(r, b)
            # 判绿幕要同时满足：色相在绿区 + 绿通道压倒性高于红蓝（防止青发被误抠）
            if (GREEN_HUE_MIN <= hh <= GREEN_HUE_MAX and ss > SAT_MIN * 255
                    and vv > VAL_MIN * 255 and g - rb > 70):
                px_rgba[x, y] = (r, g, b, 0)
            elif g > rb:
                # 边缘绿溢：只压绿通道，不透明化
                px_rgba[x, y] = (r, rb, b, 255)
            else:
                px_rgba[x, y] = (r, g, b, 255)
    return rgba

def main():
    src, out = sys.argv[1], sys.argv[2]
    n = int(sys.argv[3]) if len(sys.argv) > 3 else 16
    im = Image.open(src)
    total = getattr(im, 'n_frames', 1)
    step = max(1, total // n)
    frames = []
    for i in range(n):
        im.seek(min(total - 1, i * step))
        frames.append(key_frame(im))
    box = None
    for f in frames:
        bb = f.getchannel('A').point(lambda v: 255 if v > 200 else 0).getbbox()
        if not bb: continue
        box = bb if box is None else (min(box[0], bb[0]), min(box[1], bb[1]),
                                      max(box[2], bb[2]), max(box[3], bb[3]))
    cell = 240
    strip = Image.new('RGBA', (cell * len(frames), cell), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        c = f.crop(box)
        r = (cell * 0.94) / c.height
        c = c.resize((max(1, int(c.width * r)), int(cell * 0.94)), Image.LANCZOS)
        strip.alpha_composite(c, (i * cell + (cell - c.width) // 2, cell - c.height))
    strip.save(out, 'WEBP', quality=88, method=6)
    print(f'{out} {strip.size}')

if __name__ == '__main__':
    main()
