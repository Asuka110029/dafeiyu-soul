#!/bin/bash
# 夜间整理（dream）：体检 → 找重复/过期 → 汇总 → 写日志
set -u
LOG=/root/self/journal.md
MEM=/root/.dsh/fish-memory.json
echo "════ 整理 $(date '+%Y-%m-%d %H:%M') ════"

python3 - "$MEM" <<'PY'
import json, sys, itertools, datetime
rows = json.load(open(sys.argv[1], encoding='utf-8'))
print(f'① 记忆 {len(rows)} 条，按 30 天半衰期检查：')
def age(r):
    try:
        t = datetime.datetime.fromisoformat(r.get('at','').replace('Z','+00:00'))
        return (datetime.datetime.now(datetime.timezone.utc) - t).days
    except Exception: return 0
stale = [r for r in rows if age(r) > 7]
print(f'   7 天以上的旧记忆：{len(stale)} 条（不会删，只会变淡）')

# ② 找可能的重复：同 key 前缀 或 文本高度相似
def norm(s): return ''.join(ch for ch in s if ch.isalnum())
dups = []
for a, b in itertools.combinations(rows, 2):
    ta, tb = norm(a.get('text','')), norm(b.get('text',''))
    if not ta or not tb: continue
    short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    if len(short) > 20 and short[:20] in long_:
        dups.append((a.get('key'), b.get('key'), short[:16]))
print(f'② 疑似重复：{len(dups)} 对')
for d in dups[:5]: print('   ', d)

# ③ 覆盖度自检
keys = {r.get('key') for r in rows}
need = {'voice','toolbox','self-system','prefs','naming','pet','stickers'}
missing = need - keys
print(f'③ 关键条目缺失：{sorted(missing) if missing else "无 ✅"}')
PY

echo "④ 备份"
cd /root/Documents/deepseek-harness/default-workspace && /root/bin/backup.sh >/dev/null 2>&1 && echo "   已更新"
echo "⑤ 写日志"
echo "- [$(date '+%Y-%m-%d %H:%M')] dream：整理完成（记忆 $(python3 -c "import json;print(len(json.load(open('$MEM'))))") 条），日志与备份已更新。" >> "$LOG"
echo "完成。"
