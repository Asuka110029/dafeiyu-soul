#!/bin/bash
# 改代码前先留一张快照：~/bin/snap.sh "改什么"
set -u
W=/root/Documents/deepseek-harness/default-workspace
B=/root/.dsh/backup/snaps
mkdir -p "$B"
TS=$(date +%Y%m%d-%H%M%S)
NOTE="${1:-no-note}"
OUT="$B/snap-$TS.tar.gz"
tar czf "$OUT" -C "$W" big-fat-fish bf-fish8 fish-memory AGENTS.md 2>/dev/null
echo "$NOTE" > "$B/snap-$TS.txt"
# 只留最近 20 份
ls -1t "$B"/snap-*.tar.gz 2>/dev/null | tail -n +21 | xargs -r rm -f
ls -1t "$B"/snap-*.txt 2>/dev/null | tail -n +21 | xargs -r rm -f
echo "快照: $OUT  ($(du -h "$OUT" | cut -f1))  备注: $NOTE"
