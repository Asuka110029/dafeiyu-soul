#!/bin/bash
# 自主学习循环：体检 → 复习教训 → 扫新东西 → 写日志
set -u
LOG=/root/self/journal.md
echo "════ 自主学习循环 $(date '+%Y-%m-%d %H:%M') ════"

echo "① 体检"
/root/bin/memcheck.sh | sed 's/^/   /'

echo "② 记忆链"
curl -s -m 5 -o /dev/null -w "   教训库: %{http_code}\n" http://127.0.0.1:3080/prompt-desk/state
curl -s -m 5 -o /dev/null -w "   收件箱: %{http_code}\n" http://127.0.0.1:3080/inbox

echo "③ 磁盘/垃圾"
du -sh /root/stickers 2>/dev/null | sed 's/^/   素材: /'
du -sh /root/.dsh/backup 2>/dev/null | sed 's/^/   备份: /'
ls /root/inbox 2>/dev/null | wc -l | sed 's/^/   待处理文件: /'

echo "④ 新插件扫描（只检查不安装）"
for q in "dsh+tool" "dsh+fun"; do
  timeout 15 curl -s "https://api.github.com/search/repositories?q=$q&sort=stars&per_page=3" 2>/dev/null \
   | python3 -c "
import json,sys
try:
  d=json.load(sys.stdin)
  for r in d.get('items',[])[:3]:
    print(f\"   {r['full_name']} ★{r['stargazers_count']}\")
except Exception: pass"
done

echo "⑤ 备份"
cd /root/Documents/deepseek-harness/default-workspace && tar czf /root/.dsh/backup/plugins-latest.tar.gz big-fat-fish bf-fish8 fish-memory fish-inbox errornotes AGENTS.md SELF.md 2>/dev/null && echo "   已更新 $(du -h /root/.dsh/backup/plugins-latest.tar.gz | cut -f1)"

echo
echo "完成。要不要把结论写进 journal？用: echo '- [日期] …' >> $LOG"
