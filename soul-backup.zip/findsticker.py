#!/usr/bin/env python3
"""按语义找贴图：findsticker.py "被怼了" [条数]"""
import json, math, re, sys
sys.path.insert(0, '/root/bin')
from synonyms import expand
IDX = '/root/stickers/index.json'

def toks(t):
    t = t.lower()
    zh = re.findall(r'[\u4e00-\u9fff]+', t)
    g = set()
    for seg in zh:
        for i in range(len(seg)-1): g.add(seg[i:i+2])
        for ch in seg: g.add(ch)
    g |= set(re.findall(r'[a-z][a-z0-9\-]{1,}', t))
    return g

def main():
    q = sys.argv[1]
    top = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    items = json.load(open(IDX, encoding='utf-8'))['items']
    docs = [toks(i['desc'] + ' ' + i['tags'] + ' ' + i['file']) for i in items]
    df = {}
    for d in docs:
        for w in d: df[w] = df.get(w, 0) + 1
    qq = expand(toks(q))
    n = len(items)
    scored = []
    for it, d in zip(items, docs):
        hit = qq & d
        if not hit: continue
        ev = sum((1.0 if len(w) > 1 else 0.45) * math.log(1 + n/df[w]) for w in hit) / max(1, len(qq))
        scored.append((ev, it['file'], it['desc']))
    scored.sort(reverse=True)
    print(f'查询: {q} | 命中 {len(scored)} 张\n')
    for ev, f, desc in scored[:top]:
        print(f'  {ev:.2f}  {f}\n        {desc}')

if __name__ == '__main__': main()
