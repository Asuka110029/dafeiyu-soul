#!/bin/bash
# 记忆链体检：一条命令看全貌
M=/root/.dsh/fish-memory.json
W=/root/Documents/deepseek-harness/default-workspace
echo "── 记忆链体检 ──"
python3 - "$M" "$W" <<'PY'
import json, os, sys, subprocess
main, w = sys.argv[1], sys.argv[2]
rows = json.load(open(main))
print(f"① 主记忆      : {len(rows)} 条  |  {os.path.getsize(main)} B")
mirror = os.path.join(w, 'memory-snapshot', 'fish-memory.json')
if os.path.exists(mirror):
    same = json.load(open(mirror)) == rows
    print(f"② 工作区镜像  : {'一致' if same else '不一致!'}  |  {os.path.getsize(mirror)} B")
else:
    print("② 工作区镜像  : 缺失!")
try:
    v = json.load(open('/root/.dsh/profiles/web/node_modules/@local/fish-memory/package.json'))['version']
    print(f"③ 插件版本    : {v}")
except Exception:
    print("③ 插件版本    : 未安装!")
snaps = len([f for f in os.listdir('/root/.dsh/backup/snaps') if f.endswith('.tar.gz')]) if os.path.isdir('/root/.dsh/backup/snaps') else 0
print(f"④ 代码快照    : {snaps} 份")
zp = os.path.join(w, 'memory-export.zip')
print(f"⑤ 导出包      : {'有 ' + str(os.path.getsize(zp)) + ' B' if os.path.exists(zp) else '缺失'}")
out = subprocess.run(['pgrep','-f','memory-snapshot/fish-memory.json'], capture_output=True, text=True).stdout.strip()
print(f"⑥ 同步守护    : {'运行中' if out else '未运行（重启 App 后被杀，需要重挂）'}")
PY
