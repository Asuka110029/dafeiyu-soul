#!/bin/bash
# 插件安装前体检：安全 + 兼容 + 注入的槽位是否真实存在
set -u
T="${1:?用法: plugin-precheck.sh <目录|包名>}"
PROFILE=/root/.dsh/profiles/web/node_modules
SLOTS=/root/.dsh/slot-names.txt
[ -d "$T" ] && PJ="$T/package.json" || PJ="$PROFILE/$T/package.json"
[ -f "$PJ" ] || { echo "❌ 找不到 package.json: $PJ"; exit 1; }
DIR=$(dirname "$PJ")
node - "$PJ" "$DIR" "$SLOTS" <<'JS'
const fs=require('fs'),path=require('path');
const [pj,dir,slotsFile]=process.argv.slice(2);
const p=JSON.parse(fs.readFileSync(pj,'utf8'));
console.log('■ 包:', p.name, p.version);
const scripts=Object.keys(p.scripts||{}).filter(s=>['preinstall','install','postinstall','prepare'].includes(s));
console.log(scripts.length? '⚠️ 安装脚本: '+scripts.join(',') : '✅ 无安装脚本');
// 槽位检查
const slots = fs.existsSync(slotsFile) ? new Set(fs.readFileSync(slotsFile,'utf8').split('\n').filter(Boolean)) : null;
const cands=[p.dsh&&p.dsh.client&&p.dsh.client.entry, p.exports&&p.exports['./client'], 'client.js','lib/client.js'].filter(Boolean);
let clientSrc=''; for(const c of cands){ const fp=path.join(dir,c); if(fs.existsSync(fp)){ clientSrc=fs.readFileSync(fp,'utf8'); break; } }
const declared = new Set();
for (const m of clientSrc.matchAll(/(?:slot|slots|register|get|use)\s*[.(]\s*['"]([a-zA-Z][\w.]*\.[\w.]+)['"]/g)) declared.add(m[1]);
for (const m of clientSrc.matchAll(/['"]([a-z][\w]*\.[a-z][\w.]*)['"]/g)) { const s=m[1]; if(/^(sidebar|conversation|shell|settings|plugins|main)\./.test(s)) declared.add(s); }
if (!clientSrc) console.log('■ 纯宿主插件（无 client.js）');
else if (slots) {
  const missing=[...declared].filter(s=>!slots.has(s) && /^(sidebar|conversation|shell|settings|plugins|main)\./.test(s));
  console.log('■ 引用槽位:', declared.size ? [...declared].join(', ') : '（未识别）');
  console.log(missing.length ? '❌ 不存在的槽位: '+missing.join(', ')+' → 装上去可能让界面起不来' : '✅ 所引槽位都真实存在');
} else console.log('■ 槽位清单缺失，跳过兼容检查（先跑 /app 里导出槽位或看 inspect）');
// 需要的客户端服务是否真实存在
const svcFile='/root/.dsh/client-services.txt';
if (clientSrc && fs.existsSync(svcFile)) {
  const have = new Set(fs.readFileSync(svcFile,'utf8').split('\n').filter(Boolean));
  const need = new Set();
  const injMatch = clientSrc.match(/const inject\s*=\s*\[([^\]]*)\]/);
  if (injMatch) for (const m of injMatch[1].matchAll(/['"]([^'"]+)['"]/g)) need.add(m[1]);
  for (const m of clientSrc.matchAll(/ctx\.get\(\s*['"]([^'"]+)['"]\s*\)/g)) need.add(m[1]);
  const miss=[...need].filter(x=>!have.has(x));
  if (need.size) console.log('■ 需要服务:', [...need].join(', '), miss.length? '\n❌ 本机没有: '+miss.join(', ')+' → 装了也用不了' : '\n✅ 服务都在');
}
// 依赖能否解析：直接 import 一次入口
try {
  const { execFileSync } = require('child_process');
  const main = path.resolve(dir, p.main || 'index.js');
  const code = `import(${JSON.stringify('file://' + main)}).then(m=>{console.log('OK')}).catch(e=>{console.log('ERR:'+e.message);process.exit(3)})`;
  const out = execFileSync(process.execPath, ['-e', code], { encoding: 'utf8', stdio: ['ignore','pipe','pipe'] });
  console.log('✅ 入口可加载');
} catch (e) {
  const msg = String((e.stderr || e.stdout || e.message || '')).split('\n').filter(Boolean).pop() || 'unknown';
  console.log('❌ 入口加载失败:', msg.slice(0, 120));
}
// 静态危险面
let hits={exec:0,cred:0,ext:0};
for (const f of [p.main||'index.js','./client.js']) {
  const fp=path.join(dir,f); if(!fs.existsSync(fp)) continue;
  const s=fs.readFileSync(fp,'utf8');
  hits.exec += (s.match(/child_process|execSync|spawnSync|new Function|eval\(/g)||[]).length;
  hits.cred += (s.match(/bridge_headers|api[_-]?key|credential/gi)||[]).length;
  hits.ext  += (s.match(/https?:\/\/[a-zA-Z0-9._\/-]+/g)||[]).filter(u=>!/127\.0\.0\.1|localhost|w3\.org|schemas|dsh\.internal/.test(u)).length;
}
console.log('■ 危险面: 执行',hits.exec,'| 凭据',hits.cred,'| 外链',hits.ext, hits.exec||hits.cred||hits.ext?'⚠️ 需人工复核':'✅ 干净');
JS
