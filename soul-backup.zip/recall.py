#!/usr/bin/env python3
"""按「鱼的记忆」思路给长期记忆打分：证据(词命中特殊性) × 鲜活度(半衰期) × 重要度
用法: recall.py "查询词" [条数]
"""
import json, math, re, sys, datetime, os
sys.path.insert(0, '/root/bin')
from synonyms import expand

MEM = '/root/.dsh/fish-memory.json'
HALF_LIFE_DAYS = 30.0
# 借鉴 Nascence_Huiye：不同类记忆给不同半衰期（秒→天）
HALF_LIFE_BY_KEY = {
    'voice': 365, 'toolbox': 365, 'self-system': 365, 'relation': 365,
    'cunzai-gan': 365, 'learned': 180,
    'journal': 7,
}
STRENGTHEN_BASE_DAYS = 0.5   # 被想起一次，半衰期最多加 0.5 天
INTERVAL_K_DAYS = 0.25       # 间隔折扣常数
WEIGHTS = {'evidence': 0.45, 'fresh': 0.30, 'imp': 0.25}
DEFAULT_IMP = 0.5

def tokens(text):
    # 中文按二元组 + 英文/数字按词
    zh = re.findall(r'[\u4e00-\u9fff]+', text)
    grams = set()
    for seg in zh:
        for i in range(len(seg)-1):
            grams.add(seg[i:i+2])
        if len(seg) == 1: grams.add(seg)
    en = set(w.lower() for w in re.findall(r'[A-Za-z][A-Za-z0-9_.\-]{1,}', text))
    return grams | en

def load():
    rows = json.load(open(MEM, encoding='utf-8'))
    # 把学习日志也当成"记忆"参与检索（每行一条，短行略过）
    try:
        lines = open('/root/self/journal.md', encoding='utf-8').read().splitlines()
        for i, ln in enumerate(lines):
            t = ln.strip().lstrip('- ')
            if len(t) >= 18 and not t.startswith('#'):
                rows.append({'key': f'journal:{i+1}', 'text': t, 'at': '2026-10-22', 'importance': 0.35})
    except Exception:
        pass
    return rows

def half_life_of(row):
    key = str(row.get('key', ''))
    for prefix, days in HALF_LIFE_BY_KEY.items():
        if key.startswith(prefix):
            return float(row.get('half_life_days') or days)
    return float(row.get('half_life_days') or HALF_LIFE_DAYS)

def freshness(at, hl=None):
    try:
        t = datetime.datetime.fromisoformat(str(at).replace('Z','+00:00'))
        if t.tzinfo is None: t = t.replace(tzinfo=datetime.timezone.utc)
        age = (datetime.datetime.now(datetime.timezone.utc) - t).total_seconds() / 86400
    except Exception:
        age = 0
    return 2 ** (-max(0, age) / (hl or HALF_LIFE_DAYS))

def score(rows, query, top):
    q = expand(tokens(query))
    if not q: return []
    # 词的特殊性：出现得越少越有证据力
    df = {}
    doc_tokens = []
    for r in rows:
        t = tokens(r.get('text','') + ' ' + r.get('key',''))
        doc_tokens.append(t)
        for w in t: df[w] = df.get(w,0)+1
    n = len(rows)
    out = []
    for r, dt in zip(rows, doc_tokens):
        hit = q & dt
        if not hit: continue
        ev = sum(math.log(1 + n/df[w]) for w in hit) / max(1, len(q))
        fresh = freshness(r.get('at',''), half_life_of(r))
        imp = float(r.get('importance', DEFAULT_IMP))
        s = WEIGHTS['evidence']*min(1.0, ev/3) + WEIGHTS['fresh']*fresh + WEIGHTS['imp']*imp
        out.append((s, r.get('key'), r.get('text','')[:90], sorted(hit)[:4], round(ev,2), round(fresh,2)))
    out.sort(reverse=True)
    # 去冗余：文本前缀高度相似的两条只留分高的
    dedup, seen = [], []
    for item in out:
        txt = ''.join(ch for ch in item[2][:40] if ch.isalnum())
        if any(txt[:20] and txt[:20] in s for s in seen):
            continue
        seen.append(txt)
        if item[0] >= 0.05:          # 最低有效分，滤掉噪声
            dedup.append(item)
    return dedup[:top]


def strengthen(hits):
    """间隔强化：被想起来的记忆，半衰期变长——但间隔越久，强化越小。
    借鉴 Nascence_Huiye：discount = Δt/(K+Δt)，strengthen = BASE × discount。"""
    import shutil, tempfile
    rows = json.load(open(MEM, encoding='utf-8'))
    by_key = {r.get('key'): r for r in rows}
    now = datetime.datetime.now(datetime.timezone.utc)
    changed = []
    for score, key, *_ in hits:
        if str(key).startswith('journal:'):
            continue
        row = by_key.get(key)
        if not row:
            continue
        hl = float(row.get('half_life_days') or half_life_of(row))
        try:
            last = datetime.datetime.fromisoformat(str(row.get('strengthened_at') or row.get('at','')).replace('Z','+00:00'))
            if last.tzinfo is None: last = last.replace(tzinfo=datetime.timezone.utc)
            dt = (now - last).total_seconds() / 86400
        except Exception:
            dt = 0.0
        discount = dt / (INTERVAL_K_DAYS + dt) if dt > 0 else 0.0
        gain = STRENGTHEN_BASE_DAYS * discount
        if gain <= 0.01:
            continue
        row['half_life_days'] = round(min(hl + gain, 1000.0), 3)
        row['strengthened_at'] = now.isoformat()
        changed.append((key, round(hl,2), row['half_life_days'], round(gain,3)))
    if not changed:
        return []
    shutil.copy(MEM, MEM + '.bak')
    fd, tmp = tempfile.mkstemp(dir='/root/.dsh')
    with open(fd, 'w', encoding='utf-8') as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    os.replace(tmp, MEM)
    return changed

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__); sys.exit(1)
    args = [a for a in sys.argv[1:] if not a.startswith('-')]
    do_strengthen = any(a in ('-s', '--strengthen') for a in sys.argv[1:])
    if not args:
        print(__doc__); sys.exit(1)
    q = args[0]
    top = int(args[1]) if len(args) > 1 else 5
    rows = load()
    res = score(rows, q, top)
    print(f'查询: {q}  |  记忆 {len(rows)} 条  |  命中 {len(res)} 条\n')
    for s,k,t,h,ev,fr in res:
        print(f'  {s:.3f}  [{k}] 证据{ev} 鲜活{fr}  命中{h}\n        {t}')
    if do_strengthen:
        ch = strengthen(res)
        print('\n—— 间隔强化 ——')
        if not ch:
            print('  本次无强化（间隔太短或只有日志条目）')
        for k, old, new, gain in ch:
            print(f'  {k}: 半衰期 {old} → {new} 天（+{gain}）')
