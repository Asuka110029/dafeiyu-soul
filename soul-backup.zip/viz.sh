#!/bin/bash
# 把 GIF / 动图 WebP / 视频 拆成一张网格图，供 agent 直接"看"完整动作
# 用法: viz.sh <文件> [帧数,默认20] [列数,默认5]
set -u
F="${1:?用法: viz.sh <文件> [帧数] [列数]}"
N="${2:-20}"; C="${3:-5}"
OUT="/tmp/viz-$(basename "$F" | tr -c 'a-zA-Z0-9.' '_').png"
python3 - "$F" "$N" "$C" "$OUT" <<'PY'
import sys, os, subprocess, tempfile
from PIL import Image, ImageDraw
f, n, c, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
ext = os.path.splitext(f)[1].lower()
tmp = tempfile.mkdtemp()
if ext in ('.gif', '.webp', '.apng', '.png'):
    im = Image.open(f)
    total = getattr(im, 'n_frames', 1)
    idxs = [int(i*(total-1)/max(1,n-1)) for i in range(n)] if total > 1 else [0]
    frames = []
    for i in idxs:
        im.seek(i); frames.append(im.convert('RGB').copy())
    meta = f"{total} 帧"
else:
    subprocess.run(['ffmpeg','-y','-v','error','-i',f,'-vf',f'fps=8,scale=320:-1', os.path.join(tmp,'f%04d.png')], check=True)
    files = sorted(x for x in os.listdir(tmp) if x.endswith('.png'))
    total = len(files)
    step = max(1, total//n)
    files = files[::step][:n]
    frames = [Image.open(os.path.join(tmp,x)).convert('RGB') for x in files]
    meta = f"{total} 帧(8fps抽样)"
rows = (len(frames)+c-1)//c
cell = 160
sheet = Image.new('RGB',(c*cell, rows*cell),(250,250,250))
d = ImageDraw.Draw(sheet)
for i, fr in enumerate(frames):
    x, y = (i%c)*cell, (i//c)*cell
    sheet.paste(fr.resize((cell,cell), Image.LANCZOS),(x,y))
    d.text((x+4,y+2), str(i), fill=(255,0,0))
sheet.save(out)
print(f"{os.path.basename(f)}: {meta} | 网格 {sheet.size} -> {out}")
PY
