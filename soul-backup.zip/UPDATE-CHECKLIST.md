# 升级后自查清单（DSHA / DSH 更新后跑一遍）

## 1. 三路由体检
```bash
/root/bin/postboot.sh
```
期望：`bf-fish8/food`、`prompt-desk/state`、`inbox` 全 200。
缺哪个：
- 全缺 → 宿主 bf-fish8 没挂；用 plugin_manager 重装 `bf-fish8`
- 只缺后两个 → 正常（宿主挂载应已覆盖；若没有，重启一次）

## 2. 重新打补丁（升级会覆盖！）
检查有没有这个 bug 补丁：
```bash
grep -c "当作空即可" /usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-app-boot/lib/index.js
```
返回 0 说明补丁没了 → 用备份的补丁文件比对后重打：
- 原始：`/root/.dsh/backup/dsh-app-boot-index.js.bak`
- 已打补丁版：`/root/.dsh/backup/dsh-app-boot-PATCHED.js`
只有在**新版本仍有同名函数**时才直接拷，否则按同样思路改 `symlinksUnder()`（ENOENT/ENOTDIR 当空）。

## 3. 记忆与素材
```bash
python3 -c "import json;print(len(json.load(open('/root/.dsh/fish-memory.json'))),'条')"
ls /root/stickers/pet/guest-*.webp | wc -l     # 应为 90
```

## 4. 恢复来源（按优先级）
1. `~/.dsh/backup/plugins-latest.tar.gz`（63 文件，含记忆）
2. 手机「下载」里的 `pre-update-*.zip`（记忆+日志+索引+脚本+补丁）
3. 快照：`~/.dsh/backup/snaps/snap-*.tar.gz`

## 5. 升级后要重做的事
- [ ] 确认 `dsh-speak-up` 配置还在（间隔 90 分钟 / 安静 23–8）
- [ ] 客户端改动需重载页面：深夜池、睡眠压力、忙碌敲代码
- [ ] 若 DSH 版本变了，检查插件 peer 依赖是否还兼容
