#!/bin/bash
# 重启后的自愈：验三路由 → 缺哪个补哪个 → 再验
set -u
check() {
  local bad=0
  for u in bf-fish8/food prompt-desk/state inbox; do
    code=$(curl -s -m 5 -o /dev/null -w "%{http_code}" "http://127.0.0.1:3080/$u")
    printf '  %-20s %s\n' "$u" "$code"
    [ "$code" = "200" ] || bad=1
  done
  return $bad
}
echo "── 第一次检查 ──"
if check; then echo "✅ 全部正常，无需修复"; exit 0; fi
echo "── 有缺失，执行补登 ──"
/root/bin/repair-profile.sh
echo "  （宿主 bf-fish8 已内置子插件加载器，正常情况下不需要补登）"
sleep 3
echo "── 第二次检查 ──"
if check; then echo "✅ 已修复"; else echo "❌ 仍有缺失：需要看启动日志"; fi
