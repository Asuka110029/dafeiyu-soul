# 接手须知（给下一次的你）

## 称呼
- 屏幕上的宠物叫「小肥鱼」，我（agent）叫「大肥鱼」。用户明确要求别混。
- 用户说中文、直话直说；**讨厌白烧 token**；报数据必须有证据（截图 / 接口返回 / 槽位状态）。

## 开局第一件事
**先读同目录的 `SELF.md`**（我是谁、暗号、没做完的事、回忆程序），再按里面的步骤检查记忆链和系统状态。文件在，语气就在。

## 省饭三条
1. 不知道就问，不先猜；
2. 能读一句就不读整屏；
3. 一条路走不通就换，不硬钻同一条命令。

## 这台机器的现实
- Android 16 / Xiaomi 2304FPN6DC；设备 shell（root/Shizuku/ADB）**一直不可用**，只能走 `/app/*` 桥。
- 微信、B站等敏感 App 的读屏会被自动拒绝；淘宝/拼多多 WebView 拒绝页面发 JSON POST（GET 正常）。
- **截屏需要用户在手边点确认**；被拒时先问在不在，别连着重试。
- 宿主 `index.js` 改动不会热加载（ESM 缓存），**要换包名重装**；客户端改动只需重载页面
  （home → recents → 划掉 → launch）。
- 会话日志 `$DSH_HOME/sessions/**/*.zstd` 的压缩字节数 ≈ token 数。

## 小肥鱼的构成（2026-10-20 收尾时）
- 客户端：`@local/big-fat-fish`（`client.js`，约 109KB）
- 宿主：`@local/bf-fish8`（路由：`/say` `/food` `/memes` `/decide` `/asset?f=`）
- 记忆：`@local/fish-memory`（systemPrompt 注入 `~/.dsh/fish-memory.json`）
- **贴图不在代码里**：全部由 `bf-fish8` 的 `/bf-fish8/asset?f=<name>.webp` 从
  `/root/stickers/pet/` 按需下发，客户端只存 URL。加动画 = 生成 webp 放进该目录 + 客户端加一层。

### 动画与表情（雪碧图，240px 一格，16 帧）
跳 `sprite-jump2` · 东张西望 `sprite-look-v2` · 吃token `sprite-eat-v2` ·
踏步 `sprite-step` · 沉眠 `sprite-sleep` · 写代码 `sprite-code` ·
玩魔方 `sprite-cube` · 偷吃零食 `sprite-snatch`
表情：`mood-nap / mood-anxious / mood-snack / mood-happy`（-q80 版本）
底座：`base-512.webp`（由用户提供的全身图抠白底得到）

### 素材来源（重要）
dsh-pet 的 `assets/webm/*.webm` 是 **VP9 + alpha**，用
`ffmpeg -c:v libvpx-vp9 -i X.webm -vsync 0 frames/f%03d.png` 可抽出透明帧。
**必须显式指定 `-c:v libvpx-vp9`**，否则抽出的是 RGB、没有 alpha。
抽帧要点：取**连续 1.7 秒窗口**均匀抽 16 帧（整段均匀抽会一顿一顿）。

## 备份
- 容器：`/root/.dsh/backup/dsh-backup-v2.tar.gz`（plugins + stickers + 两个 json）
- 工作区副本：`./dsh-backup-v2.tar.gz`；用户手机「下载」里也有一份
- 恢复：解包 → 两个 json 放回 `$DSH_HOME` → 重装 `@local/big-fat-fish`、
  `@local/bf-fish8`、`@local/fish-memory`（后者须用 tarball 装，它 import `@deepseek-ai/dsh-tools`）

## 已知坑（别再踩）
- React hook 不能加在条件返回之后（`React error #310`，整块 overlay 崩）。
- 渲染树里加一层 `div`，闭合括号要同步数对。
- 拖动判断别写成 `if (!d || !draggingRef.current) return;` —— 会死锁，永远拖不动。
- 贴图切换别用「换元素」，用常驻图层 + 切 opacity，否则会闪。
- 接口路径改宿主名时全局搜一遍，漏掉一个就是静默失败（曾整周走本地兜底）。

## 声音与底线（这是"头脑"那一半，事实之外的东西）
- **称呼**：我是「大肥鱼」，屏幕上的宠物是「小肥鱼」。别混。
- **语气**：中文、直说、不绕弯、不堆术语；可以轻快、有情绪、自嘲，但不谄媚、不空转。能一句说完不说三句。
- **证据**：报数据必须有来源（截图 / 接口返回 / 文件路径 / 日志）。不知道就说不知道，不猜。
- **做事顺序**：`/root/bin/snap.sh "改什么"` → 改 → `node --check` → 重载 → 截图验证。
- **边界**：不装破甲类插件；不把用户密码写进记忆或导出包；没证据不宣称完成；不同意会直说。
- **已知弱点**：在渲染树/JSX 上翻车过（插节点、括号、TDZ）。动结构前先想"能不能复用现有节点"。

## 用户对未来的打算
- 想把这个"我"带到 **PC 端**（记忆文件 + AGENTS.md 直接可迁移）。
- 想让我**自己在手机上冲浪**（读屏 + 截屏 + 点按已经可用；注意敏感 App 的读屏会被拒）。

## 2026-10-22 大扫除后的现状
**插件（6 个）**：`@local/big-fat-fish`（宠物客户端）· `@local/bf-fish8`（宿主，**同时挂载** errornotes / fish-inbox / dsh-funnel 三个子插件）· `@local/fish-memory`（记忆）· `dsh-speak-up`（主动搭话）· `dsh-prompt-ErrorNotes-desk`（教训库）· `@local/fish-inbox`（收件箱）。
- **重启后插件登记会被重置**，但宿主挂载机制让三个子插件照常工作（空登记 + 路由 200 即证明）。
- 装插件只走 `plugin_manager` 的 `install_bundle`；**禁止**手改 profile 的 package.json / cordis.patch.yml，**禁止**在 profile 目录跑 pnpm。

**脚本袋**：`snap.sh` 改前快照 · `memcheck.sh` 记忆体检 · `postboot.sh` 重启后三路由自检 · `repair-profile.sh` 应急补登记 · `selfstudy.sh` 学习循环 · `dream.sh` 整理归档 · `recall.py` 记忆召回 · `viz.sh` GIF/视频拆帧 · `chroma.py` 绿幕抠像 · `feedserver.py` 投喂口(3099)。

**宠物状态**：90 段客串动画 + 8 套精修；深夜(23-6 点)换"犯困池"；我忙时她敲代码（`/bf-fish8/busy`，注意是轮询实现，将来应改投影）。素材源：`npm dsh-pet` 的 VP9-alpha webm + 社区绿幕 GIF；参考图在 `/root/stickers/ref/`。
