#!/bin/bash
# 一键修复：把本地插件重新登记进 profile 的 dependencies + dsh.profile.bundles，并补软链
set -u
P=/root/.dsh/profiles/web
W=/root/Documents/deepseek-harness/default-workspace
python3 - "$P" "$W" <<'PY'
import json, os, sys
profile, ws = sys.argv[1], sys.argv[2]
plugins = [
    ("dsh-prompt-ErrorNotes-desk", f"{ws}/errornotes"),
    ("@local/fish-inbox",          f"{ws}/fish-inbox"),
    ("dsh-funnel",                 f"{ws}/dsh-funnel"),
    ("dsh-speak-up",               f"{ws}/dsh-speak-up"),
]
pj = os.path.join(profile, "package.json")
d = json.load(open(pj))
deps = d.setdefault("dependencies", {})
bundles = d.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
changed = []
for name, path in plugins:
    if not os.path.isdir(path):
        print(f"⚠️ 缺目录: {path}"); continue
    if name not in deps:
        deps[name] = f"link:{path}"; changed.append(f"deps+{name}")
    if name not in bundles:
        bundles.append(name); changed.append(f"bundles+{name}")
    link = os.path.join(profile, "node_modules", name)
    os.makedirs(os.path.dirname(link), exist_ok=True)
    if not os.path.exists(link):
        os.symlink(path, link); changed.append(f"link+{name}")
json.dump(d, open(pj, "w"), indent=2, ensure_ascii=False)
print("修复项:", ", ".join(changed) if changed else "无（都已在册）")
PY
