#!/bin/bash
# 完整备份：插件 + 记忆 + 日志 + 交接文档（一个包全带走）
set -u
W=/root/Documents/deepseek-harness/default-workspace
OUT=/root/.dsh/backup/plugins-latest.tar.gz
cd "$W" || exit 1
TMP=$(mktemp -d)
# 1) 插件源码
for d in big-fat-fish bf-fish8 fish-inbox errornotes dsh-funnel dsh-speak-up; do
  [ -d "$d" ] && cp -r "$d" "$TMP/" 2>/dev/null
done
# 2) 文档
cp AGENTS.md SELF.md UPDATE-CHECKLIST.md "$TMP/" 2>/dev/null
# 3) 记忆与日志（关键！以前漏了）
cp /root/.dsh/fish-memory.json "$TMP/" 2>/dev/null
cp /root/.dsh/fish-memes.json "$TMP/" 2>/dev/null
mkdir -p "$TMP/memory"
cp /root/self/journal.md "$TMP/memory/" 2>/dev/null
# 4) 贴图索引（不含大图，省空间）
cp /root/stickers/index.json "$TMP/memory/" 2>/dev/null
tar czf "$OUT" -C "$TMP" . 2>/dev/null
rm -rf "$TMP"
echo "备份: $OUT ($(du -h "$OUT" | cut -f1))"
echo "内容: $(tar tzf "$OUT" | wc -l) 个文件，含记忆 $([ "$(tar tzf "$OUT" | grep -c 'fish-memory.json')" -gt 0 ] && echo 是 || echo 否)"
