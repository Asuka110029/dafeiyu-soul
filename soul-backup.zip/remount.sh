#!/bin/bash
# 重启后插件路由不挂时的救命脚本：关→开→复检
set -u
check() {
  for u in bf-fish8/food prompt-desk/state inbox; do
    printf '  %-20s ' "$u"
    curl -s -m 5 -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:3080/$u"
  done
}
echo "── 重挂前 ──"; check
echo "── 提示：插件开关请让 agent 用 plugin_manager 执行 ──"
echo "   dsh-prompt-ErrorNotes-desk / @local/fish-inbox"
echo "── 重挂后用本脚本结尾的复检 ──"
check
